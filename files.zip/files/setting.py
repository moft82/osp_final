#! /usr/bin/python

import nltk
nltk.download("stopwords")
nltk.download("punkt")